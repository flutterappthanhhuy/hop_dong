import 'dart:convert';
import 'dart:io';
import 'package:archive/archive_io.dart';

/// Quét placeholder {{field}} trong file .xlsx
class XlsxFieldScanner {
  static final _placeholder = RegExp(r'\{\{\s*([A-Za-z0-9_]+)\s*\}\}');

  static Future<List<String>> scanFields(String xlsxPath) async {
    final bytes = File(xlsxPath).readAsBytesSync();
    final archive = ZipDecoder().decodeBytes(bytes);

    // Chỉ quét các sheet
    final targets = archive.files.where((f) =>
    f.isFile &&
        f.name.startsWith('xl/worksheets/sheet') &&
        f.name.endsWith('.xml'));

    final seen = <String>{};
    final result = <String>[];

    for (final file in targets) {
      final xml = utf8.decode(file.content as List<int>);

      // Bỏ tag XML → lấy text thô
      final textOnly = xml.replaceAll(RegExp(r'<[^>]+>'), '');
      for (final m in _placeholder.allMatches(textOnly)) {
        final key = m.group(1)?.trim();
        if (key != null && key.isNotEmpty && seen.add(key)) {
          result.add(key);
        }
      }
    }

    return result;
  }
}
