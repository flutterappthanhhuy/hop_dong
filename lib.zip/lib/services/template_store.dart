import 'dart:io';
import 'package:hive/hive.dart';
import 'package:hop_dong/services/xlsx_field_scanner.dart';
import 'package:uuid/uuid.dart';
import 'package:path/path.dart' as p;

import '../models/template_file.dart';
import 'docx_field_scanner.dart';

class TemplateStore {
  static const boxName = 'template_files';

  // NEW: meta boxes
  static const _metaVersionBox = 'template_meta';           // id -> int (version)
  static const _metaFolderMapBox = 'template_folder_map';   // id -> String? (folderId)

  Future<void> init() async {
    if (!Hive.isBoxOpen(boxName)) {
      await Hive.openBox<TemplateFile>(boxName);
    }
    if (!Hive.isBoxOpen(_metaVersionBox)) {
      await Hive.openBox(_metaVersionBox);
    }
    if (!Hive.isBoxOpen(_metaFolderMapBox)) {
      await Hive.openBox(_metaFolderMapBox);
    }
  }

  Box<TemplateFile> get _box => Hive.box<TemplateFile>(boxName);

  List<TemplateFile> getAll() => _box.values.toList();

  TemplateFile? getById(String id) => _box.get(id);

  Future<void> upsert(TemplateFile t) async => _box.put(t.id, t);

  Future<void> add(TemplateFile t) async => _box.put(t.id, t);

  Future<void> remove(String id) async {
    final t = _box.get(id);
    if (t != null) {
      try {
        final f = File(t.filePath);
        if (await f.exists()) await f.delete();
      } catch (_) {}
      try {
        await t.delete();
      } catch (_) {
        await _box.delete(id);
      }
    }
    final meta = Hive.box(_metaVersionBox);
    final folders = Hive.box(_metaFolderMapBox);
    await meta.delete(id);
    await folders.delete(id);
  }

  Future<void> clear() async => _box.clear();

  // =======================
  // VERSION META
  // =======================
  Future<void> bumpVersion(String id) async {
    final meta = Hive.box(_metaVersionBox);
    final cur = (meta.get(id) as int?) ?? 0;
    await meta.put(id, cur + 1);
  }

  Future<int> getVersion(String id) async {
    final meta = Hive.box(_metaVersionBox);
    return (meta.get(id) as int?) ?? 0;
  }

  // =======================
  // FOLDER MAP META
  // =======================
  Future<void> moveToFolder(String id, String? folderId) async {
    final t = _box.get(id);
    if (t != null) {
      t.templateFolderId = folderId;
      t.updatedAt = DateTime.now();
      await t.save();
    }
  }

  Future<String?> getFolderId(String templateId) async {
    final folders = Hive.box(_metaFolderMapBox);
    final v = folders.get(templateId);
    return (v is String) ? v : null;
  }

  Future<Map<String, String?>> getAllFolderMap() async {
    final m = <String, String?>{};
    for (final t in _box.values) {
      m[t.id] = t.templateFolderId;
    }
    return m;
  }

  // =======================
  // IMPORT TEMPLATE
  // =======================
  Future<TemplateFile> importDocxTemplate(String filePath, {String? folderId}) async {
    final fields = await DocxFieldScanner.scanFields(filePath);

    final t = TemplateFile(
      id: const Uuid().v4(),
      name: p.basename(filePath),
      kind: TemplateKind.docx,
      filePath: filePath,
      fields: fields,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
      version: 1,
      templateFolderId: folderId,
    );

    await add(t);
    return t;
  }

  Future<TemplateFile> importXlsxTemplate(String filePath, {String? folderId}) async {
    final fields = await XlsxFieldScanner.scanFields(filePath);

    final t = TemplateFile(
      id: const Uuid().v4(),
      name: p.basename(filePath),
      kind: TemplateKind.xlsx,
      filePath: filePath,
      fields: fields,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
      version: 1,
      templateFolderId: folderId,
    );

    await add(t);
    return t;
  }
  Future<TemplateFile> importTemplate(String filePath, {String? folderId}) async {
    final ext = p.extension(filePath).toLowerCase();
    List<String> fields = [];
    TemplateKind kind;

    if (ext == '.docx') {
      fields = await DocxFieldScanner.scanFields(filePath);
      kind = TemplateKind.docx;
    } else if (ext == '.xlsx') {
      fields = await XlsxFieldScanner.scanFields(filePath);
      kind = TemplateKind.xlsx;
    } else {
      throw UnsupportedError('File không được hỗ trợ: $ext');
    }

    final t = TemplateFile(
      id: const Uuid().v4(),
      name: p.basename(filePath),
      kind: kind,
      filePath: filePath,
      fields: fields,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
      version: 1,
      templateFolderId: folderId,
    );

    await add(t);
    return t;
  }
}
